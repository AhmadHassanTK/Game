package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class viewGame extends JFrame {
	
	private JPanel handOne;
	private JPanel handTwo;
	private JPanel Field1;
	private JPanel Field2;
	private JPanel Hero1;
	private JPanel Hero2;
	private JPanel endTurn;
	//private JPanel endTurn2;
	private JPanel deckHero1;
	private JPanel deckHero2;
	private JPanel userHeroPower1;
	private JPanel userHeroPower2;
	private JPanel startPanel;
	
	private JPanel begPanel;
	
	private JPanel begPanel2;
	
	
	public viewGame () {
		this.setVisible(true);
		this.setLayout(null);
		this.setBounds(0, 0, 2000, 1080);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//--------------------------------------------------------------------------------
		
		handOne = new JPanel();
		handOne.setBounds(100, 700, 1000, 100);
		handOne.setBackground(Color.red);
		handOne.setLayout(new GridLayout());
		
		this.add(handOne);
		
		
		
		//-------------------------------------------------------------------------------------
		
		handTwo = new JPanel();
		handTwo = new JPanel();
		handTwo.setBounds(100, 30, 1000, 100);
		handTwo.setBackground(Color.red);
		handTwo.setLayout(new GridLayout());
		
		this.add(handTwo);
		
		//--------------------------------------------------------------------------------------
		
		Field2 = new JPanel();
		Field2.setBounds(100, 230, 1000, 185);
		Field2.setBackground(Color.red);
		Field2.setLayout(new GridLayout());
		
		this.add(Field2);
		
		//--------------------------------------------------------------------------------------
		
		Field1 = new JPanel();
		Field1.setBounds(100, 415, 1000, 185);
		Field1.setBackground(Color.red);
		Field1.setLayout(new GridLayout());
		
		this.add(Field1);
		
		//--------------------------------------------------------------------------------------
		
		Hero1 = new JPanel();
		Hero1.setBounds(550, 600, 100, 100);
		Hero1.setBackground(Color.red);
		this.add(Hero1);
		
		//-----------------------------------------------------------------------------------------
		
		Hero2 = new JPanel();
		Hero2.setBounds(550, 130, 100, 100);
		Hero2.setBackground(Color.red);
		this.add(Hero2);
		
		//----------------------------------------------------------------------------------------
		
		endTurn = new JPanel();
		endTurn.setBounds(1130, 380, 100, 100);
		endTurn.setBackground(Color.red);
		this.add(endTurn);
		
		
		//----------------------------------------------------------------------------------------
		
		
		deckHero1 = new JPanel();
		deckHero1.setBounds(1250, 500, 100, 100);
		deckHero1.setBackground(Color.red);
		this.add(deckHero1);
		
		//--------------------------------------------------------------------------------------
		
		deckHero2 = new JPanel();
		deckHero2.setBounds(1250, 250, 100, 100);
		deckHero2.setBackground(Color.red);
		this.add(deckHero2);
		
		//--------------------------------------------------------------------------------------
		
		userHeroPower1 = new JPanel();
		userHeroPower1.setBounds(1200, 700, 100, 100);
		userHeroPower1.setBackground(Color.red);
		this.add(userHeroPower1);
		
		//--------------------------------------------------------------------------------------
		
		userHeroPower2 = new JPanel();
		userHeroPower2.setBounds(1200, 30, 100, 100);
		userHeroPower2.setBackground(Color.red);
		this.add(userHeroPower2);
		
		//--------------------------------------------------------------------------------------
		
		startPanel = new JPanel();
		startPanel.setBounds(0,0,100,100);
		this.add(startPanel);
		
		begPanel = new JPanel();
		begPanel.setBounds(200,200,1000,200);
		begPanel.setLayout(new GridLayout());
		this.add(begPanel);
		
		//-----------------------------------------------------------------------------------
		
		begPanel2 = new JPanel();
		begPanel2.setBounds(200,500,1000,200);
		begPanel2.setLayout(new GridLayout());
		this.add(begPanel2);
	}
	
	
	public static void main(String [] args) {
		viewGame n = new viewGame();
	}


	public JPanel getHandOne() {
		return handOne;
	}


	public void setHandOne(JPanel handOne) {
		this.handOne = handOne;
	}


	public JPanel getHandTwo() {
		return handTwo;
	}


	public void setHandTwo(JPanel handTwo) {
		this.handTwo = handTwo;
	}


	public JPanel getField1() {
		return Field1;
	}


	public void setField1(JPanel field) {
		Field1 = field;
	}


	public JPanel getHero1() {
		return Hero1;
	}
	
	public JPanel getField2() {
		return Field2;
	}


	public void setField2(JPanel field) {
		Field2 = field;
	}


	public void setHero1(JPanel hero1) {
		Hero1 = hero1;
	}


	public JPanel getHero2() {
		return Hero2;
	}

//	public void setHeroVisible() {
//		deckHero2.setVisible(false);
//	}

	public void setHero2(JPanel hero2) {
		Hero2 = hero2;
	}



	public JPanel getDeckHero1() {
		return deckHero1;
	}


	public void setDeckHero1(JPanel deckHero1) {
		this.deckHero1 = deckHero1;
	}


	public JPanel getDeckHero2() {
		return deckHero2;
	}


	public void setDeckHero2(JPanel deckHero2) {
		this.deckHero2 = deckHero2;
	}


	public JPanel getUserHeroPower1() {
		return userHeroPower1;
	}


	public void setUserHeroPower1(JPanel userHeroPower1) {
		this.userHeroPower1 = userHeroPower1;
	}


	public JPanel getUserHeroPower2() {
		return userHeroPower2;
	}


	public void setUserHeroPower2(JPanel userHeroPower2) {
		this.userHeroPower2 = userHeroPower2;
	}


	
	public JPanel getEndTurn() {
		return endTurn;
	}


	public void setEndTurn(JPanel endTurn) {
		this.endTurn = endTurn;
	}


	public JPanel getStartPanel() {
		return startPanel;
	}


	public void setStartPanel(JPanel startPanel) {
		this.startPanel = startPanel;
	}


	public JPanel getBegPanel() {
		return begPanel;
	}


	public void setBegPanel(JPanel begPanel) {
		this.begPanel = begPanel;
	}


	public JPanel getBegPanel2() {
		return begPanel2;
	}


	public void setBegPanel2(JPanel begPanel2) {
		this.begPanel2 = begPanel2;
	}
	
	
	
}

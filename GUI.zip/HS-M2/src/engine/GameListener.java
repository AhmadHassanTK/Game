package engine;

import model.cards.Card;
import model.cards.minions.Minion;

public interface GameListener {
	public void onGameOver();

	void onHandUpdated(Card c);

	// public void onFieldUpdated(Minion m);

	public void onPowerUpdate();

	public void onEndTurn();

	public void onPlayMinion(Minion m);

	public void onCastSpell();

	public void onMininAttacking();

}

package model.heroes;

import exceptions.FullHandException;
import model.cards.Card;
import model.cards.minions.Minion;

public interface HeroListener {
	public void onHeroDeath();

	public void damageOpponent(int amount);

	public void endTurn() throws FullHandException, CloneNotSupportedException;

	public void onDrawCard(Card c);

	public void onPlayingMinion(Minion m);

	void onUseHeroPower();

	public void onCastSpell();

	public void onMinionAttack();

}

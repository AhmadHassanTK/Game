package GameController;

import java.awt.Dimension;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import engine.Game;
import engine.GameListener;
import exceptions.CannotAttackException;
import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotSummonedException;
import exceptions.NotYourTurnException;
import exceptions.TauntBypassException;
import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.spells.AOESpell;
import model.cards.spells.FieldSpell;
import model.cards.spells.HeroTargetSpell;
import model.cards.spells.LeechingSpell;
import model.cards.spells.MinionTargetSpell;
import model.heroes.Hero;
import model.heroes.Hunter;
import model.heroes.Mage;
import model.heroes.Paladin;
import model.heroes.Priest;
import model.heroes.Warlock;
import view.viewGame;

public class ControllerGame implements ActionListener, GameListener {
	private Game game;
	private viewGame view;
	private ArrayList<JButton> buttonsofPlayerOne;
	private ArrayList<JButton> randomButtons;
	private JButton Hero1;
	private JButton Hero2;
	private JButton DeckOne;
	private JButton DeckTwo;
	private ArrayList<JButton> PlayerHand1;
	private ArrayList<JButton> PlayerHand2;
	private ArrayList<JButton> PlayerField1;
	private ArrayList<JButton> PlayerField2;
	private int tmp;
	private int tmpS;

	private boolean flagHeroAttack;
	private boolean flagMinionAttack;

	private boolean FlagLeeching;
	private boolean FlagMinion;
	private boolean FlagHero;

	private boolean tmpMage1;
	private boolean tmpMage2;
	private boolean tmpPriest1;
	private boolean tmpPriest2;

	private JButton start;

	private ArrayList<JButton> heroesOfPlayerOne;
	private ArrayList<JButton> heroesOfPlayerTwo;

	private String PLayerOneChoice;
	private String PlayerTwoChoice;

	private static Hero player1;
	private static Hero player2;

	private static boolean star = false;
	private static volatile boolean running = true;

	private Hero HeroOne;
	private Hero HeroTwo;
	private boolean FlagF1;
	private boolean FlagF2;

	public ControllerGame() throws FullHandException, CloneNotSupportedException, IOException {
		// game = new Game(player1, player2);
		view = new viewGame();
		view.getHandOne().setVisible(false);
		view.getField1().setVisible(false);
		view.getHandTwo().setVisible(false);
		view.getField2().setVisible(false);
		view.getEndTurn().setVisible(false);
		view.getUserHeroPower1().setVisible(false);
		view.getUserHeroPower2().setVisible(false);
		view.getDeckHero1().setVisible(false);
		view.getDeckHero2().setVisible(false);
		view.getHero1().setVisible(false);
		view.getHero2().setVisible(false);

		PlayerHand1 = new ArrayList<JButton>();
		PlayerHand2 = new ArrayList<JButton>();
		PlayerField1 = new ArrayList<JButton>();
		PlayerField2 = new ArrayList<JButton>();
		flagHeroAttack = false;
		flagMinionAttack = false;
		FlagLeeching = false;
		FlagMinion = false;
		FlagHero = false;
		tmpMage1 = false;
		tmpMage2 = false;
		tmpPriest1 = false;
		tmpPriest1 = false;
		start = new JButton();

		heroesOfPlayerOne = new ArrayList<JButton>();
		heroesOfPlayerTwo = new ArrayList<JButton>();

		PLayerOneChoice = "";
		PlayerTwoChoice = "";

		FlagF1 = false;
		FlagF2 = false;

		// game.setListener(this);

		// -----------------------------------------------------------------------------------

//		start.setText("Start");
//		view.getStartPanel().add(start);
//		start.addActionListener(this);

		ImageIcon magePic = new ImageIcon("mage.png");
		JButton B1 = new JButton(magePic);
		B1.setToolTipText("Mage");
		B1.setText("Mage");
		B1.addActionListener(this);

		ImageIcon hunterPic = new ImageIcon("hunter.png");
		JButton B2 = new JButton(hunterPic);
		B2.setToolTipText("Hunter");
		B2.setText("Hunter");
		B2.addActionListener(this);

		ImageIcon paladinPic = new ImageIcon("paladinnew.png");
		JButton B3 = new JButton(paladinPic);
		B3.setToolTipText("Paladin");
		B3.setText("Paladin");
		B3.addActionListener(this);

		ImageIcon priestPic = new ImageIcon("priest.png");
		JButton B4 = new JButton(priestPic);
		B4.setToolTipText("Priest");
		B4.setText("Priest");
		B4.addActionListener(this);

		ImageIcon warlockPic = new ImageIcon("warlock.png");
		JButton B5 = new JButton(warlockPic);
		B5.setToolTipText("Warlock");
		B5.setText("Warlock");
		B5.addActionListener(this);

		view.getBegPanel().add(B1);
		heroesOfPlayerOne.add(B1);
		view.getBegPanel().add(B2);
		heroesOfPlayerOne.add(B2);
		view.getBegPanel().add(B3);
		heroesOfPlayerOne.add(B3);
		view.getBegPanel().add(B4);
		heroesOfPlayerOne.add(B4);
		view.getBegPanel().add(B5);
		heroesOfPlayerOne.add(B5);

		view.getBegPanel().setVisible(true);

		JButton B6 = new JButton(magePic);
		B6.setToolTipText("Mage");
		B6.setText("Mage");
		B6.addActionListener(this);

		JButton B7 = new JButton(hunterPic);
		B7.setToolTipText("Hunter");
		B7.setText("Hunter");
		B7.addActionListener(this);

		JButton B8 = new JButton(paladinPic);
		B8.setToolTipText("Paladin");
		B8.setText("Paladin");
		B8.addActionListener(this);

		JButton B9 = new JButton(priestPic);
		B9.setToolTipText("Priest");
		B9.setText("Priest");
		B9.addActionListener(this);

		JButton B10 = new JButton(warlockPic);
		B10.setToolTipText("Warlock");
		B10.setText("Warlock");
		B10.addActionListener(this);

		view.getBegPanel2().add(B6);
		heroesOfPlayerTwo.add(B6);
		view.getBegPanel2().add(B7);
		heroesOfPlayerTwo.add(B7);
		view.getBegPanel2().add(B8);
		heroesOfPlayerTwo.add(B8);
		view.getBegPanel2().add(B9);
		heroesOfPlayerTwo.add(B9);
		view.getBegPanel2().add(B10);
		heroesOfPlayerTwo.add(B10);

		view.getBegPanel2().setVisible(false);

		view.revalidate();
		view.repaint();

	}

	public void test() {

		for (int i = 0; i < HeroOne.getHand().size(); i++) {
			JButton b = new JButton();
			if (HeroOne.getHand().get(i) instanceof Minion) {
				ImageIcon min = new ImageIcon("minion.png");
				b = new JButton(min);
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(
						"" + HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
				b.addActionListener(this);
				view.getHandOne().add(b);
				PlayerHand1.add(b);
			} else {
				ImageIcon spel = new ImageIcon("spell.png");
				b = new JButton(spel);
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(
						"" + HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
				b.addActionListener(this);
				view.getHandOne().add(b);
				PlayerHand1.add(b);
			}
		}
		// view.getHandOne().setVisible(false);

		// ------------------------------------------------------------------------------------------

		for (int i = 0; i < HeroOne.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getField().get(i).toString());
			b.setVisible(true);
			// b.setPreferredSize(new Dimension(50, 50));
			b.setToolTipText("" + HeroOne.getField().get(i).getAttack() + "," + HeroOne.getField().get(i).isDivine()
					+ ", " + HeroOne.getField().get(i).getCurrentHP() + "," + HeroOne.getField().get(i).getName());
			view.getField1().add(b);
			PlayerField1.add(b);
		}
		// view.getField1().setVisible(false);
		// ------------------------------------------------------------------------

		for (int i = 0; i < HeroTwo.getHand().size(); i++) {
			JButton b = new JButton();
			b.addActionListener(this);
			b.setText("Card");
			b.setToolTipText(HeroTwo.getHand().get(i).getManaCost() + " " + HeroTwo.getHand().get(i).getName());
			view.getHandTwo().add(b);
			PlayerHand2.add(b);

		}
		// view.getHandTwo().setVisible(false);
		// -------------------------------------------------------------------------------------------

		for (int i = 0; i < HeroTwo.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroTwo.getField().get(i).toString());
			b.setToolTipText("" + HeroTwo.getField().get(i).getAttack() + "," + HeroTwo.getField().get(i).isDivine()
					+ ", " + HeroTwo.getField().get(i).getCurrentHP());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerField2.add(b);

		}
		// view.getField2().setVisible(false);

		// -------------------------------------------------------------------------------------------

		if (HeroOne instanceof Mage) {
			ImageIcon magePic = new ImageIcon("mageButton.png");
			Hero1 = new JButton(magePic);
			Hero1.setPreferredSize(new Dimension(100, 100));
			Hero1.setText(HeroOne.getName());
			view.getHero1().add(Hero1);
			Hero1.addActionListener(this);
			Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
					+ HeroOne.getCurrentManaCrystals());

		}
		if (HeroOne instanceof Hunter) {
			ImageIcon hunterPic = new ImageIcon("hunterButton.png");

			Hero1 = new JButton(hunterPic);
			Hero1.setPreferredSize(new Dimension(100, 100));
			Hero1.setText(HeroOne.getName());
			view.getHero1().add(Hero1);
			Hero1.addActionListener(this);
			Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
					+ HeroOne.getCurrentManaCrystals());

		}
		if (HeroOne instanceof Paladin) {
			ImageIcon paladinrPic = new ImageIcon("paladinButton.png");

			Hero1 = new JButton(paladinrPic);
			Hero1.setPreferredSize(new Dimension(100, 100));
			Hero1.setText(HeroOne.getName());
			view.getHero1().add(Hero1);
			Hero1.addActionListener(this);
			Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
					+ HeroOne.getCurrentManaCrystals());

		}
		if (HeroOne instanceof Warlock) {
			ImageIcon warlockrPic = new ImageIcon("warlockButton.png");

			Hero1 = new JButton(warlockrPic);
			Hero1.setPreferredSize(new Dimension(100, 100));
			Hero1.setText(HeroOne.getName());
			view.getHero1().add(Hero1);
			Hero1.addActionListener(this);
			Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
					+ HeroOne.getCurrentManaCrystals());

		}
		if (HeroOne instanceof Priest) {
			ImageIcon priestkrPic = new ImageIcon("priestButton.png");

			Hero1 = new JButton(priestkrPic);
			Hero1.setPreferredSize(new Dimension(100, 100));
			Hero1.setText(HeroOne.getName());
			view.getHero1().add(Hero1);
			Hero1.addActionListener(this);
			Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
					+ HeroOne.getCurrentManaCrystals());

		}

		// -------------------------------------------------------------------------------------------

		if (HeroTwo instanceof Mage) {

			ImageIcon magePic = new ImageIcon("mageButton.png");
			Hero2 = new JButton(magePic);
			Hero2.setPreferredSize(new Dimension(100, 100));
			Hero2.setText(HeroTwo.getName());
			view.getHero2().add(Hero2);
			Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
					+ HeroTwo.getCurrentManaCrystals());
		}
		if (HeroTwo instanceof Hunter) {
			ImageIcon hunterPic = new ImageIcon("hunterButton.png");

			Hero2 = new JButton(hunterPic);
			Hero2.setPreferredSize(new Dimension(100, 100));
			Hero2.setText(HeroTwo.getName());
			view.getHero2().add(Hero2);
			Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
					+ HeroTwo.getCurrentManaCrystals());

		}
		if (HeroTwo instanceof Paladin) {
			ImageIcon paladinrPic = new ImageIcon("paladinButton.png");

			Hero2 = new JButton(paladinrPic);
			Hero2.setPreferredSize(new Dimension(100, 100));
			Hero2.setText(HeroTwo.getName());
			view.getHero2().add(Hero2);
			Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
					+ HeroTwo.getCurrentManaCrystals());
		}
		if (HeroTwo instanceof Warlock) {
			ImageIcon warlockrPic = new ImageIcon("warlockButton.png");

			Hero2 = new JButton(warlockrPic);
			Hero2.setPreferredSize(new Dimension(100, 100));
			Hero2.setText(HeroTwo.getName());
			view.getHero2().add(Hero2);
			Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
					+ HeroTwo.getCurrentManaCrystals());

		}
		if (HeroTwo instanceof Priest) {
			ImageIcon priestkrPic = new ImageIcon("priestButton.png");

			Hero2 = new JButton(priestkrPic);

			Hero2.setPreferredSize(new Dimension(100, 100));
			Hero2.setText(HeroTwo.getName());
			view.getHero2().add(Hero2);
			Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
					+ HeroTwo.getCurrentManaCrystals());
		}

		// -------------------------------------------------------------------------------------------

		JButton d = new JButton();
		d.setPreferredSize(new Dimension(100, 100));
		d.setText("end Turn");
		view.getEndTurn().add(d);
		d.addActionListener(this);
		// view.getEndTurn().setVisible(false);

		// -------------------------------------------------------------------------------------------

		DeckOne = new JButton();
		DeckOne.setPreferredSize(new Dimension(100, 100));
		DeckOne.setText("Deck1");

		view.getDeckHero1().add(DeckOne);

		DeckOne.setToolTipText("" + game.getCurrentHero().getDeck().size());
		DeckOne.addActionListener(this);
		// view.getDeckHero1().setVisible(false);

		// ------------------------------------------------------------------------------------------

		DeckTwo = new JButton();
		DeckTwo.setPreferredSize(new Dimension(100, 100));
		DeckTwo.setText("Deck2");
		view.getDeckHero2().add(DeckTwo);
		DeckTwo.addActionListener(this);
		DeckTwo.setToolTipText("" + game.getOpponent().getDeck().size());
		// view.getDeckHero2().setVisible(false);
		// ------------------------------------------------------------------------------------------

		JButton g = new JButton();
		g.setPreferredSize(new Dimension(100, 100));
		g.setText("useHeroP1");
		view.getUserHeroPower1().add(g);
		g.addActionListener(this);
		// view.getUserHeroPower1().setVisible(false);

		// ---------------------------------------------------------------------------------------------

		JButton h = new JButton();
		h.setPreferredSize(new Dimension(100, 100));
		h.setText("useHeroP2");
		view.getUserHeroPower2().add(h);
		h.addActionListener(this);
		// view.getUserHeroPower2().setVisible(false);

		// ------------------------------------------------------------------------------------------------

		view.revalidate();
		view.repaint();
	}

	public static void main(String[] args) throws FullHandException, CloneNotSupportedException, IOException {
//		Hero hun = new Paladin();
//		// hun.setCurrentManaCrystals(3);
//		Hero n = new Hunter();
//		// n.setCurrentManaCrystals(3);

//		Hero player1 = null;
//		Hero player2 = null;
//		
//		if(PLayerOneChoice.equalsIgnoreCase("mage"))
//			 player1=new Mage();
//		else if(PLayerOneChoice.equalsIgnoreCase("hunter"))
//			 player1=new Hunter();
//		else if(PLayerOneChoice.equalsIgnoreCase("paladin"))
//			 player1=new Paladin();
//		else if(PLayerOneChoice.equalsIgnoreCase("Priest"))
//			 player1=new Priest();
//		else if(PLayerOneChoice.equalsIgnoreCase("Warlock"))
//			 player1=new Warlock();
//		
//
//		if(PlayerTwoChoice.equalsIgnoreCase("mage"))
//			 player2=new Mage();
//		else if(PlayerTwoChoice.equalsIgnoreCase("hunter"))
//			 player2=new Hunter();
//		else if(PlayerTwoChoice.equalsIgnoreCase("paladin"))
//			 player2=new Paladin();
//		else if(PlayerTwoChoice.equalsIgnoreCase("Priest"))
//			 player2=new Priest();
//		else if(PlayerTwoChoice.equalsIgnoreCase("Warlock"))
//			 player2=new Warlock();
//		

		ControllerGame game1 = new ControllerGame();
		boolean f = true;
		while (running) {
			// System.out.println();
			if (star) {
				// System.out.println(star);
				game1.test();
				running = false;
				break;
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (heroesOfPlayerOne.contains(e.getSource())) {
//			 Hero player1 = null;

			PLayerOneChoice = ((JButton) e.getSource()).getText();

			if (PLayerOneChoice.equalsIgnoreCase("mage"))
				try {
					System.out.println("heeeereeeee");
					player1 = new Mage();
					System.out.println(player1.getName());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PLayerOneChoice.equalsIgnoreCase("hunter"))
				try {
					player1 = new Hunter();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PLayerOneChoice.equalsIgnoreCase("paladin"))
				try {
					player1 = new Paladin();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PLayerOneChoice.equalsIgnoreCase("Priest"))
				try {
					player1 = new Priest();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PLayerOneChoice.equalsIgnoreCase("Warlock"))
				try {
					player1 = new Warlock();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			view.getBegPanel().setVisible(false);
			view.getBegPanel2().setVisible(true);
		}
		if (heroesOfPlayerTwo.contains(e.getSource())) {
			Hero player2 = null;
			PlayerTwoChoice = ((JButton) e.getSource()).getText();
			view.getBegPanel().setVisible(false);
			view.getBegPanel2().setVisible(false);

			if (PlayerTwoChoice.equalsIgnoreCase("mage"))
				try {
					player2 = new Mage();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PlayerTwoChoice.equalsIgnoreCase("hunter"))
				try {
					System.out.println("herrrr2");
					player2 = new Hunter();
					System.out.println(player2.getName());
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PlayerTwoChoice.equalsIgnoreCase("paladin"))
				try {
					player2 = new Paladin();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PlayerTwoChoice.equalsIgnoreCase("Priest"))
				try {
					player2 = new Priest();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			else if (PlayerTwoChoice.equalsIgnoreCase("Warlock"))
				try {
					player2 = new Warlock();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			System.out.println("########" + player2.getName());
			System.out.println(star);

			try {
				System.out.println("########" + player1.getName());
				game = new Game(player1, player2);
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			game.setListener(this);
			HeroOne = game.getCurrentHero();
			HeroTwo = game.getOpponent();
			view.getHandOne().setVisible(true);
			view.getHandTwo().setVisible(true);
			view.getField1().setVisible(true);
			view.getField2().setVisible(true);
			view.getEndTurn().setVisible(true);
			view.getUserHeroPower1().setVisible(true);
			view.getUserHeroPower2().setVisible(true);
			view.getDeckHero1().setVisible(true);
			view.getDeckHero2().setVisible(true);
			view.getHero1().setVisible(true);
			view.getHero2().setVisible(true);
			star = true;

		}

//			view.getHandOne().setVisible(true);
//			view.getHandTwo().setVisible(true);
//			view.getField1().setVisible(true);
//			view.getField2().setVisible(true);
//			view.getEndTurn().setVisible(true);
//			view.getUserHeroPower1().setVisible(true);
//			view.getUserHeroPower2().setVisible(true);
//			view.getDeckHero1().setVisible(true);
//			view.getDeckHero2().setVisible(true);
//			view.getHero1().setVisible(true);
//			view.getHero2().setVisible(true);

//---------------------------------------attack-------------------------------------------------------	
		int tmpF1 = 0;
		int tmpF2 = 0;
		if (PlayerField1.contains(e.getSource())) {
			int rField1 = PlayerField1.indexOf(e.getSource());
			tmpF1 = rField1;
			flagMinionAttack = true;

		}
		if (PlayerField2.contains(e.getSource())) {
			int rField2 = PlayerField2.indexOf(e.getSource());
			tmpF2 = rField2;
			FlagF2 = true;
			// System.out.println("loop2");
		}
		if (PlayerField2.contains(e.getSource()) && flagMinionAttack) {
			int r = PlayerField2.indexOf(e.getSource());
			flagMinionAttack = false;
			System.out.println("hiiii" + flagMinionAttack);
			try {
				System.out.println(tmp);
				HeroOne.attackWithMinion(HeroOne.getField().get(tmpF1), HeroTwo.getField().get(r));
			} catch (CannotAttackException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Cann't Attack", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (TauntBypassException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Taunt!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotSummonedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Summoned!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

		if (PlayerField1.contains(e.getSource()) && FlagF2 == true) {
			int r3 = PlayerField1.indexOf(e.getSource());
			System.out.println("hiiii" + tmp);
			FlagF2 = false;
			System.out.println("loop4");
			try {
				System.out.println(tmp);
				HeroTwo.attackWithMinion(HeroTwo.getField().get(tmpF2), HeroOne.getField().get(r3));
			} catch (CannotAttackException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Cann't Attack", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (TauntBypassException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Taunt!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotSummonedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Summoned!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

		JButton x = (JButton) e.getSource();
		if (game != null && x.getText().equalsIgnoreCase(HeroTwo.getName()) && flagMinionAttack) {
			flagMinionAttack = false;
			System.out.println("lol" + flagMinionAttack);
			try {
				HeroOne.attackWithMinion(HeroOne.getField().get(tmpF1), HeroTwo);
			} catch (CannotAttackException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Cann't Attack", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (TauntBypassException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Taunt!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotSummonedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Summoned!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && x.getText().equalsIgnoreCase(HeroOne.getName()) && FlagF2) {
			FlagF2 = false;
			System.out.println("lol" + flagMinionAttack);
			try {
				HeroTwo.attackWithMinion(HeroTwo.getField().get(tmpF2), HeroOne);
			} catch (CannotAttackException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Cann't Attack", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (TauntBypassException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Taunt!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotSummonedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Summoned!", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

//----------------------------------Draw a card-------------------------------------------------------------------			

		JButton b = (JButton) e.getSource();
		Card c;
		int r1 = 0;
		int r2 = 0;
		Minion d = new Minion("test", 5, Rarity.BASIC, 9, 9, false, false, false);
		if (b.getText().equals("Deck1")) {

			try {

				c = HeroOne.drawCard();

//				JButton f = new JButton();
//				f.setPreferredSize(new Dimension(100, 100));
//				f.setText("Deck1");
//				f.setToolTipText("hi");
//				view.getDeckHero1().add(f);
//				f.addActionListener(this);

			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (b.getText().equals("Deck2")) {
			try {
				c = HeroTwo.drawCard();

//				JButton f = new JButton();
//				f.setPreferredSize(new Dimension(100, 100));
//				f.setText("Deck2");
//				f.setToolTipText("hi");
//				view.getDeckHero2().add(f);
//				f.addActionListener(this);
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
//-------------------------------Use hero power-----------------------------------------------------------------

		JButton f = (JButton) e.getSource();
		if (f.getText().equalsIgnoreCase("UseHerop1") && HeroOne instanceof Mage) {
			tmpMage1 = true;

		}
		if (PlayerField2.contains(b) && tmpMage1) {
			int t = PlayerField2.indexOf(b);
			d = (Minion) (HeroTwo.getField().get(t));
			tmpMage1 = false;

			try {
				((Mage) HeroOne).useHeroPower(d);
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equalsIgnoreCase(HeroTwo.getName()) && tmpMage1) {
			try {
				((Mage) HeroOne).useHeroPower(HeroTwo);
				tmpMage1 = false;
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

		if (f.getText().equalsIgnoreCase("UseheroP2") && HeroTwo instanceof Mage) {
			tmpMage2 = true;

		}
		if (PlayerField1.contains(b) && tmpMage2) {
			int t = PlayerField1.indexOf(b);
			d = (Minion) (HeroTwo.getField().get(t));
			tmpMage2 = false;

			try {
				((Mage) HeroTwo).useHeroPower(d);
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

		if (game != null && HeroTwo != null && b.getText().equalsIgnoreCase(HeroOne.getName()) && tmpMage2) {
			try {
				((Mage) HeroTwo).useHeroPower(HeroOne);
				tmpMage2 = false;
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

		if (f.getText().equalsIgnoreCase("UseHerop1") && HeroOne instanceof Priest) {
			tmpPriest1 = true;

		}
		JButton j = (JButton) e.getSource();
		if (PlayerField1.contains(j) && tmpPriest1) {
			int t = PlayerField1.indexOf(j);
			d = (Minion) (HeroOne.getField().get(t));
			tmpPriest1 = false;
			try {
				((Priest) HeroOne).useHeroPower(d);

			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equalsIgnoreCase(HeroOne.getName()) && tmpPriest1) {
			try {
				((Priest) HeroOne).useHeroPower(HeroOne);
				tmpPriest1 = false;
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}

		}

		if (f.getText().equalsIgnoreCase("UseHeroP2") && HeroTwo instanceof Priest) {
			tmpPriest2 = true;

		}
		j = (JButton) e.getSource();
		if (PlayerField2.contains(j) && tmpPriest2) {
			int t = PlayerField2.indexOf(j);
			d = (Minion) (HeroTwo.getField().get(t));
			tmpPriest2 = false;
			try {
				((Priest) HeroTwo).useHeroPower(d);

			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && HeroTwo != null && b.getText().equalsIgnoreCase(HeroTwo.getName()) && tmpPriest2) {
			try {
				((Priest) HeroTwo).useHeroPower(HeroTwo);
				tmpPriest2 = false;
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}

		}

		if (game != null && b.getText().equalsIgnoreCase("useHeroP1") && HeroOne instanceof Paladin) {
			try {
				HeroOne.useHeroPower();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equalsIgnoreCase("useHeroP2") && HeroTwo instanceof Paladin) {
			try {
				HeroTwo.useHeroPower();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equalsIgnoreCase("useHeroP1") && HeroOne instanceof Hunter) {
			try {
				HeroOne.useHeroPower();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equalsIgnoreCase("useHeroP2") && HeroTwo instanceof Hunter) {
			try {
				HeroTwo.useHeroPower();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (game != null && b.getText().equals("useHeroP1") && game.getCurrentHero() instanceof Warlock) {
			try {
				HeroOne.useHeroPower();

			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (b.getText().equals("useHeroP2") && HeroTwo instanceof Warlock) {
			try {
				HeroTwo.useHeroPower();

			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (HeroPowerAlreadyUsedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "You Already Used Your Hero Power", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

//---------------------------------------------------End turn---------------------------------------------

		if (b.getText().equals("end Turn")) {
			try {
				System.out.println("hi");
				game.endTurn();

			} catch (FullHandException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Hand Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (CloneNotSupportedException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Clone Is Not Supported", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

//--------------------------------------------------Play with minion-------------------------------------------
		r1 = 0;
		r2 = 0;
		if (PlayerHand1.contains(b))
			r1 = PlayerHand1.indexOf(b);
		if (PlayerHand2.contains(b))
			r2 = PlayerHand2.indexOf(b);
		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof Minion) {
			// int r = PlayerHand1.indexOf(b);
			// if (game.getCurrentHero().getHand().get(r) instanceof Minion)
			d = (Minion) (HeroOne.getHand().get(r1));
			try {
				HeroOne.playMinion(d);

			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof Minion) {
			d = (Minion) (HeroTwo.getHand().get(r2));
			try {
				HeroTwo.playMinion(d);
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (FullFieldException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}

//--------------------------------------------------Cast Spell-----------------------------------------------	
//			else if (PlayerHand1.contains(b) && game.getCurrentHero().getHand().get(r) instanceof Minion) {
//				d = (Minion) (game.getCurrentHero().getHand().get(r));
//				try {
//					game.getCurrentHero().playMinion(d);
//				} catch (NotYourTurnException e1) {
//					// TODO Auto-generated catch block
//					JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message",
//							JOptionPane.INFORMATION_MESSAGE);
//					e1.printStackTrace();
//				} catch (NotEnoughManaException e1) {
//					// TODO Auto-generated catch block
//					JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
//							JOptionPane.INFORMATION_MESSAGE);
//					e1.printStackTrace();
//				} catch (FullFieldException e1) {
//					// TODO Auto-generated catch block
//					JOptionPane.showMessageDialog(null, "Your Field Is Full", "Game Message",
//							JOptionPane.INFORMATION_MESSAGE);
//					e1.printStackTrace();
//				}
//			}
		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof FieldSpell) {
			try {

				HeroOne.castSpell((FieldSpell) HeroOne.getHand().get(r1));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof FieldSpell) {
			try {

				HeroTwo.castSpell((FieldSpell) HeroTwo.getHand().get(r2));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
		}
		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof HeroTargetSpell) {
			int min = PlayerHand1.indexOf(b);
			tmpS = min;
			FlagHero = true;
		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof HeroTargetSpell) {
			int min = PlayerHand2.indexOf(b);
			tmpS = min;
			FlagHero = true;
		}
		if (game != null && b.getText().equals(HeroOne.getName()) && FlagHero == true) {
			try {
				HeroTwo.castSpell((HeroTargetSpell) HeroTwo.getHand().get(tmpS), HeroOne);
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagHero = false;

		}
		if (HeroTwo != null && b.getText().equals(HeroTwo.getName()) && FlagHero == true) {
			try {
				HeroOne.castSpell((HeroTargetSpell) HeroOne.getHand().get(tmpS), HeroTwo);
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagHero = false;

		}
		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof AOESpell) {
			try {

				HeroOne.castSpell((AOESpell) HeroOne.getHand().get(r1), HeroTwo.getField());
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}

		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof AOESpell) {
			try {

				HeroTwo.castSpell((AOESpell) HeroTwo.getHand().get(r2), HeroOne.getField());
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}

		}
		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof MinionTargetSpell) {
			int min = PlayerHand1.indexOf(b);
			tmpS = min;
			FlagMinion = true;
		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof MinionTargetSpell) {
			int min = PlayerHand2.indexOf(b);
			tmpS = min;
			FlagMinion = true;
		}
		if (PlayerField2.contains(b) && FlagMinion == true) {
			try {
				System.out.println("111");
				int sp = PlayerField2.indexOf(b);
				HeroOne.castSpell((MinionTargetSpell) HeroOne.getHand().get(tmpS), HeroTwo.getField().get(sp));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagMinion = false;
		}
		if (PlayerField1.contains(b) && FlagMinion == true) {
			try {
				System.out.println("2222");
				int sp = PlayerField1.indexOf(b);
				HeroTwo.castSpell((MinionTargetSpell) HeroOne.getHand().get(tmpS), HeroOne.getField().get(sp));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagMinion = false;
		}
//				if (PlayerField2.contains(b) && FlagMinion == true) {
//					try {
//						int sp = PlayerField2.indexOf(b);
//						HeroOne.castSpell((MinionTargetSpell) HeroOne.getHand().get(tmpS), HeroOne.getField().get(sp));
//					} catch (NotYourTurnException e1) {
//						// TODO Auto-generated catch block
//						JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message",
//								JOptionPane.INFORMATION_MESSAGE);
//						e1.printStackTrace();
//					} catch (NotEnoughManaException e1) {
//						// TODO Auto-generated catch block
//						JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
//								JOptionPane.INFORMATION_MESSAGE);
//						e1.printStackTrace();
//					} catch (InvalidTargetException e1) {
//						// TODO Auto-generated catch block
//						JOptionPane.showMessageDialog(null, "This Is Invalid Target", "Game Message",
//								JOptionPane.INFORMATION_MESSAGE);
//						e1.printStackTrace();
//					}
//					FlagMinion = false;
//				}

		if (PlayerHand1.contains(b) && HeroOne.getHand().get(r1) instanceof LeechingSpell) {
			int min = PlayerHand1.indexOf(b);
			tmpS = min;
			FlagLeeching = true;
		}
		if (PlayerField2.contains(b) && FlagLeeching == true) {

			int sp = PlayerField2.indexOf(b);
			try {
				HeroOne.castSpell((LeechingSpell) HeroOne.getHand().get(tmpS), HeroTwo.getField().get(sp));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagLeeching = false;

		}
		if (PlayerHand2.contains(b) && HeroTwo.getHand().get(r2) instanceof LeechingSpell) {
			int min = PlayerHand2.indexOf(b);
			tmpS = min;
			FlagLeeching = true;
		}
		if (PlayerField1.contains(b) && FlagLeeching == true) {
			int sp = PlayerField1.indexOf(b);

			try {
				HeroTwo.castSpell((LeechingSpell) HeroTwo.getHand().get(tmpS), HeroOne.getField().get(sp));
			} catch (NotYourTurnException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not your Turn", "Game Message", JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			} catch (NotEnoughManaException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Not Enough Manacrystals", "Game Message",
						JOptionPane.INFORMATION_MESSAGE);
				e1.printStackTrace();
			}
			FlagLeeching = false;
		}

	}

	@Override
	public void onHandUpdated(Card c) {
//

//		b.addActionListener(this);
//		b.setText(c.toString());
//		// b.setVisible(true);
//		view.getHandOne().add(b);

		DeckOne.setToolTipText("" + HeroOne.getDeck().size());
		DeckTwo.setToolTipText("" + HeroTwo.getDeck().size());

		view.getHandOne().removeAll();
		view.getHandTwo().removeAll();
		PlayerHand1.clear();
		PlayerHand2.clear();
		for (int i = 0; i < HeroOne.getHand().size(); i++) {

			JButton b ;
			if(HeroOne.getHand().get(i) instanceof Minion) {
			ImageIcon min = new ImageIcon("minion.png");
			b = new JButton(min);
			}
			else {
				ImageIcon min = new ImageIcon("spell.png");
				b = new JButton(min);
			}
			b.addActionListener(this);
			b.setText(HeroOne.getHand().get(i).toString());
			b.setToolTipText("" + HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			b.setVisible(true);
			view.getHandOne().add(b);
			PlayerHand1.add(b);
			if (HeroOne.equals(game.getCurrentHero())) {
				
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			} else {
				b=new JButton();
				b.setText("Card");
			}
		}

		for (int i = 0; i < HeroTwo.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			if (HeroTwo.equals(game.getCurrentHero())) {
				b.setText(HeroTwo.getHand().get(i).toString());
				b.setToolTipText(HeroTwo.getHand().get(i).getManaCost() + " " + HeroTwo.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
			b.setVisible(true);
			b.setPreferredSize(new Dimension(50, 50));
			view.getHandTwo().add(b);
			PlayerHand2.add(b);
		}

		view.repaint();
		view.revalidate();

	}
//
//	@Override
//	public void onFieldUpdated(Minion m) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public void onPowerUpdate() {

//		if (game.getCurrentHero() instanceof Hunter) {
		Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
				+ HeroTwo.getCurrentManaCrystals());
		Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
				+ HeroOne.getCurrentManaCrystals());

//		}

//		if ((game.getCurrentHero() instanceof Paladin)) {
		view.getField1().removeAll();
		PlayerField1.clear();

		view.getField2().removeAll();
		PlayerField2.clear();

//			Hero1.setToolTipText(
//					"" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals()
//							+ ", " + HeroOne.getCurrentManaCrystals());
		for (int i = 0; i < HeroOne.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getField().get(i).toString());
			b.setVisible(true);
			b.setToolTipText("" + HeroOne.getField().get(i).getAttack() + "," + HeroOne.getField().get(i).isDivine()
					+ ", " + HeroOne.getField().get(i).getCurrentHP());
			// b.setPreferredSize(new Dimension(50, 50));
			view.getField1().add(b);
			PlayerField1.add(b);
		}

		for (int i = 0; i < HeroTwo.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroTwo.getField().get(i).toString());
			b.setToolTipText("" + HeroTwo.getField().get(i).getAttack() + "," + HeroTwo.getField().get(i).isDivine()
					+ ", " + HeroTwo.getField().get(i).getCurrentHP());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerField2.add(b);

		}

//		}
//		if ((game.getCurrentHero() instanceof Warlock)) {
//			Hero1.setToolTipText(
//					"" + game.getCurrentHero().getCurrentHP() + ", " + game.getCurrentHero().getCurrentManaCrystals()
//							+ ", " + game.getCurrentHero().getCurrentManaCrystals());
//
//			Hero2.setToolTipText("" + game.getOpponent().getCurrentHP() + ", "
//					+ game.getOpponent().getCurrentManaCrystals() + ", " + game.getOpponent().getCurrentManaCrystals());

//			for (int i = 0; i < game.getCurrentHero().getField().size(); i++) {
//
//				JButton b = new JButton();
//				b.addActionListener(this);
//				b.setText(game.getCurrentHero().getField().get(i).toString());
//				b.setVisible(true);
//				// b.setPreferredSize(new Dimension(50, 50));
//				view.getField1().add(b);
//			}
//			for (int i = 0; i < game.getCurrentHero().getHand().size(); i++) {
//
//				JButton b = new JButton();
//				b.addActionListener(this);
//				b.setText(game.getCurrentHero().getHand().get(i).toString());
//				b.setVisible(true);
//				// b.setPreferredSize(new Dimension(50, 50));
//				view.getHandOne().add(b);
//			}
		// }

//		if ((game.getCurrentHero() instanceof Mage)) {
//			view.getField1().removeAll();
//			view.getField2().removeAll();
//
//			PlayerField1.clear();
//			PlayerField2.clear();
//			Hero1.setToolTipText(
//					"" + game.getCurrentHero().getCurrentHP() + ", " + game.getCurrentHero().getCurrentManaCrystals()
//							+ ", " + game.getCurrentHero().getCurrentManaCrystals());
//			Hero2.setToolTipText("" + game.getOpponent().getCurrentHP() + ", "
//					+ game.getOpponent().getCurrentManaCrystals() + ", " + game.getOpponent().getCurrentManaCrystals());
//			for (int i = 0; i < game.getCurrentHero().getField().size(); i++) {
//				System.out.println("lolololo");
//				JButton b = new JButton();
//				b.addActionListener(this);
//				b.setText(game.getCurrentHero().getField().get(i).toString());
//				b.setVisible(true);
//				// b.setPreferredSize(new Dimension(50, 50));
//				b.setToolTipText("" + game.getCurrentHero().getField().get(i).getAttack() + ","
//						+ game.getCurrentHero().getField().get(i).isDivine() + ", "
//						+ game.getCurrentHero().getField().get(i).getCurrentHP());
//				view.getField1().add(b);
//				PlayerField1.add(b);
//			}
//			for (int i = 0; i < game.getOpponent().getField().size(); i++) {
//				System.out.println(game.getOpponent().getField().get(i).isDivine());
//				System.out.println(game.getOpponent().getField().get(i).getCurrentHP());
//				JButton b = new JButton();
//				b.addActionListener(this);
//				b.setText(game.getOpponent().getField().get(i).toString());
//				b.setToolTipText("" + game.getOpponent().getField().get(i).getAttack() + ","
//						+ game.getOpponent().getField().get(i).isDivine() + ", "
//						+ game.getOpponent().getField().get(i).getCurrentHP());
//				b.setVisible(true);
//				view.getField2().add(b);
//				PlayerField2.add(b);
//			}
//		}

//		if ((game.getCurrentHero() instanceof Priest)) {
//			view.getField1().removeAll();
//			PlayerField1.clear();
//			Hero1.setToolTipText(
//					"" + game.getCurrentHero().getCurrentHP() + ", " + game.getCurrentHero().getCurrentManaCrystals()
//							+ ", " + game.getCurrentHero().getCurrentManaCrystals());
//			Hero2.setToolTipText("" + game.getOpponent().getCurrentHP() + ", "
//					+ game.getOpponent().getCurrentManaCrystals() + ", " + game.getOpponent().getCurrentManaCrystals());
//			System.out.println("5ra");
//			for (int i = 0; i < game.getCurrentHero().getField().size(); i++) {
//
//				JButton b = new JButton();
//				b.addActionListener(this);
//				b.setText(game.getCurrentHero().getField().get(i).toString());
//				b.setVisible(true);
//				// b.setPreferredSize(new Dimension(50, 50));
//				b.setToolTipText("" + game.getCurrentHero().getField().get(i).getAttack() + ","
//						+ game.getCurrentHero().getField().get(i).isDivine() + ", "
//						+ game.getCurrentHero().getField().get(i).getCurrentHP());
//				view.getField1().add(b);
//				PlayerField1.add(b);
//			}
//		}

		view.revalidate();
		view.repaint();
	}

	@Override
	public void onEndTurn() {
//		System.out.println(game.getCurrentHero().getName());
//		System.out.println(game.getOpponent().getName());
		view.getHandOne().removeAll();
		view.getHandTwo().removeAll();
		view.getField1().removeAll();
		view.getField2().removeAll();
		PlayerHand1.clear();
		PlayerHand2.clear();
		PlayerField1.clear();
		PlayerField2.clear();
		for (int i = 0; i < HeroOne.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getHand().get(i).toString());
			b.setToolTipText("" + HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			b.setVisible(true);
			view.getHandOne().add(b);
			PlayerHand1.add(b);
			if (HeroOne.equals(game.getCurrentHero())) {
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
		}
		for (int i = 0; i < HeroOne.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getField().get(i).toString());
			b.setVisible(true);
			b.setToolTipText("" + HeroOne.getField().get(i).getAttack() + "," + HeroOne.getField().get(i).isDivine()
					+ ", " + HeroOne.getField().get(i).getCurrentHP());
			// b.setPreferredSize(new Dimension(50, 50));
			view.getField1().add(b);
			PlayerField1.add(b);
		}
		for (int i = 0; i < HeroTwo.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			if (HeroTwo.equals(game.getCurrentHero())) {
				b.setText(HeroTwo.getHand().get(i).toString());
				b.setToolTipText(HeroTwo.getHand().get(i).getManaCost() + " " + HeroTwo.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
			b.setVisible(true);
			b.setPreferredSize(new Dimension(50, 50));
			view.getHandTwo().add(b);
			PlayerHand2.add(b);
		}
		for (int i = 0; i < HeroTwo.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroTwo.getField().get(i).toString());
			b.setToolTipText("" + HeroTwo.getField().get(i).getAttack() + "," + HeroTwo.getField().get(i).isDivine()
					+ ", " + HeroTwo.getField().get(i).getCurrentHP());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerField2.add(b);

		}

		// Hero1.setText(game.getCurrentHero().getName());
		Hero1.addActionListener(this);
		DeckOne.setToolTipText("" + HeroOne.getDeck().size());
		DeckOne.addActionListener(this);
		Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
				+ HeroOne.getCurrentManaCrystals());

		// Hero2.setText(game.getOpponent().getName());
		Hero2.addActionListener(this);
		DeckTwo.setToolTipText("" + HeroTwo.getDeck().size());
		Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
				+ HeroTwo.getCurrentManaCrystals());

		System.out.println("hi from enf=d turn");

		view.revalidate();
		view.repaint();
	}

	@Override
	public void onPlayMinion(Minion m) {

		view.getHandOne().removeAll();
		view.getHandTwo().removeAll();
		view.getField1().removeAll();
		view.getField2().removeAll();
		PlayerHand1.clear();
		PlayerHand2.clear();
		PlayerField1.clear();
		PlayerField2.clear();

		for (int i = 0; i < HeroOne.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);

			b.setVisible(true);
			view.getHandOne().add(b);
			PlayerHand1.add(b);

			if (HeroOne.equals(game.getCurrentHero())) {
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
			System.out.println(HeroOne.getHand());
			System.out.println(PlayerHand1);
		}
		for (int i = 0; i < HeroOne.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getField().get(i).toString());
			b.setToolTipText("" + HeroOne.getField().get(i).getAttack() + "," + HeroOne.getField().get(i).isDivine()
					+ ", " + HeroOne.getField().get(i).getCurrentHP() );
			// System.o
			// b.setVisible(true);
			b.setPreferredSize(new Dimension(50, 50));
			view.getField1().add(b);
			b.setVisible(true);
			view.getField1().setVisible(true);

			PlayerField1.add(b);

		}
		for (int i = 0; i < HeroTwo.getHand().size(); i++) {
			JButton b = new JButton();
			b.addActionListener(this);
			if (HeroTwo.equals(game.getCurrentHero())) {
				b.setText(HeroTwo.getHand().get(i).toString());
				b.setToolTipText(HeroTwo.getHand().get(i).getManaCost() + " " + HeroTwo.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
			b.setVisible(true);
			b.setPreferredSize(new Dimension(50, 50));
			view.getHandTwo().add(b);
			PlayerHand2.add(b);
		}
		for (int i = 0; i < HeroTwo.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroTwo.getField().get(i).toString());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerField2.add(b);
			b.setToolTipText(HeroTwo.getField().get(i).getManaCost() + " " + HeroTwo.getField().get(i).getName());
		}
		DeckOne.setToolTipText("" + HeroOne.getDeck().size());
		DeckTwo.setToolTipText("" + HeroTwo.getDeck().size());

		Hero1.setToolTipText("" + game.getCurrentHero().getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
				+ HeroOne.getCurrentManaCrystals());

		Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
				+ HeroTwo.getCurrentManaCrystals());

		view.revalidate();
		view.repaint();
	}

	@Override
	public void onGameOver() {
		System.out.println("GameOver");
		JPanel GameOver = new JPanel();
		TextArea a = new TextArea();
		GameOver.add(a);
		if (game.getCurrentHero().equals(HeroOne))

			JOptionPane.showMessageDialog(null, "GameOver  HeroOne is the winner ", "Game Message",
					JOptionPane.INFORMATION_MESSAGE);
		if (game.getCurrentHero().equals(HeroTwo))
			JOptionPane.showMessageDialog(null, "GameOver  HeroTwo is the winner ", "Game Message",
					JOptionPane.INFORMATION_MESSAGE);

		view.add(GameOver);

		GameOver.setBounds(500, 500, 100, 100);
		view.revalidate();
		view.repaint();
	}

	@Override
	public void onCastSpell() {
		view.getHandOne().removeAll();
		view.getHandTwo().removeAll();
		view.getField1().removeAll();
		view.getField2().removeAll();
		PlayerHand1.clear();
		PlayerHand2.clear();
		PlayerField1.clear();
		PlayerField2.clear();
		for (int i = 0; i < HeroOne.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getHand().get(i).toString());
			b.setToolTipText("" + HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			b.setVisible(true);
			view.getHandOne().add(b);
			PlayerHand1.add(b);
			if (HeroOne.equals(game.getCurrentHero())) {
				b.setText(HeroOne.getHand().get(i).toString());
				b.setToolTipText(HeroOne.getHand().get(i).getManaCost() + " " + HeroOne.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
		}
		for (int i = 0; i < HeroOne.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroOne.getField().get(i).toString());
			b.setVisible(true);
			b.setToolTipText("" + HeroOne.getField().get(i).getAttack() + "," + HeroOne.getField().get(i).isDivine()
					+ ", " + HeroOne.getField().get(i).getCurrentHP());
			// b.setPreferredSize(new Dimension(50, 50));
			view.getField1().add(b);
			PlayerField1.add(b);
		}
		for (int i = 0; i < HeroTwo.getHand().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			if (HeroTwo.equals(game.getCurrentHero())) {
				b.setText(HeroTwo.getHand().get(i).toString());
				b.setToolTipText(HeroTwo.getHand().get(i).getManaCost() + " " + HeroTwo.getHand().get(i).getName());
			} else {
				b.setText("Card");
			}
			b.setVisible(true);
			b.setPreferredSize(new Dimension(50, 50));
			view.getHandTwo().add(b);
			PlayerHand2.add(b);
		}
		for (int i = 0; i < HeroTwo.getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(HeroTwo.getField().get(i).toString());
			b.setToolTipText("" + HeroTwo.getField().get(i).getAttack() + "," + HeroTwo.getField().get(i).isDivine()
					+ ", " + HeroTwo.getField().get(i).getCurrentHP());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerField2.add(b);

		}

		// Hero1.setText(game.getCurrentHero().getName());
		Hero1.addActionListener(this);
		DeckOne.setToolTipText("" + HeroOne.getDeck().size());
		DeckOne.addActionListener(this);
		Hero1.setToolTipText("" + HeroOne.getCurrentHP() + ", " + HeroOne.getCurrentManaCrystals() + ", "
				+ HeroOne.getCurrentManaCrystals());

		// Hero2.setText(game.getOpponent().getName());
		Hero2.addActionListener(this);
		DeckTwo.setToolTipText("" + HeroTwo.getDeck().size());
		Hero2.setToolTipText("" + HeroTwo.getCurrentHP() + ", " + HeroTwo.getCurrentManaCrystals() + ", "
				+ HeroTwo.getCurrentManaCrystals());

		System.out.println("hi from enf=d turn");

		view.revalidate();
		view.repaint();
	}

	@Override
	public void onMininAttacking() {

		view.getField1().removeAll();
		view.getField2().removeAll();

		PlayerField1.clear();
		PlayerField2.clear();

		for (int i = 0; i < game.getCurrentHero().getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(game.getCurrentHero().getField().get(i).toString());
			b.setVisible(true);
			b.setToolTipText("" + game.getCurrentHero().getField().get(i).getAttack() + ","
					+ game.getCurrentHero().getField().get(i).isDivine() + ", "
					+ game.getCurrentHero().getField().get(i).getCurrentHP() + ","
					+ game.getCurrentHero().getField().get(i).isAttacked());
			// b.setPreferredSize(new Dimension(50, 50));
			view.getField1().add(b);
			PlayerField1.add(b);
		}

		for (int i = 0; i < game.getOpponent().getField().size(); i++) {

			JButton b = new JButton();
			b.addActionListener(this);
			b.setText(game.getOpponent().getField().get(i).toString());
			b.setToolTipText("" + game.getOpponent().getField().get(i).getAttack() + ","
					+ game.getOpponent().getField().get(i).isDivine() + ", "
					+ game.getOpponent().getField().get(i).getCurrentHP() + ","
					+ game.getOpponent().getField().get(i).isAttacked());
			b.setVisible(true);
			view.getField2().add(b);
			PlayerHand2.add(b);

		}
		Hero1.setToolTipText(
				"" + game.getCurrentHero().getCurrentHP() + ", " + game.getCurrentHero().getCurrentManaCrystals() + ", "
						+ game.getCurrentHero().getCurrentManaCrystals());

		Hero2.setToolTipText("" + game.getOpponent().getCurrentHP() + ", " + game.getOpponent().getCurrentManaCrystals()
				+ ", " + game.getOpponent().getCurrentManaCrystals());
		view.revalidate();
		view.repaint();

	}

}

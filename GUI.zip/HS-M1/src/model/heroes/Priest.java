package model.heroes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.NotEnoughManaException;
import exceptions.NotYourTurnException;
import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.minions.MinionListener;
import model.cards.spells.DivineSpirit;
import model.cards.spells.HolyNova;
import model.cards.spells.ShadowWordDeath;

public class Priest extends Hero implements MinionListener {

	public Priest() throws IOException, CloneNotSupportedException {
		super("Anduin Wrynn");
	}

	@Override
	public void buildDeck() throws IOException, CloneNotSupportedException {
		ArrayList<Minion> neutrals = getNeutralMinions(getAllNeutralMinions("neutral_minions.csv"), 13);
		getDeck().addAll(neutrals);

		for (int i = 0; i < 2; i++) {
			getDeck().add(new DivineSpirit());
			getDeck().add(new HolyNova());
			getDeck().add(new ShadowWordDeath());
		}
		Minion velen = new Minion("Prophet Velen", 7, Rarity.LEGENDARY, 7, 7, false, false, false);
		velen.setListener((Hero) this);
		getDeck().add(velen);
		Collections.shuffle(getDeck());
		for (int i = 0; i < this.getDeck().size(); i++) {
			if (this.getDeck().get(i) instanceof Minion) {
				((Minion) this.getDeck().get(i)).setListener(this);
			}
		}
	}

	public void useHeroPower(Hero target) throws NotEnoughManaException, HeroPowerAlreadyUsedException,
			NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException {
		super.useHeroPower();
		if (this.getField().size() == 7)
			throw new FullFieldException("the feild is full");

		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Prophet Velen"))
				target.setCurrentHP(target.getCurrentHP() + 8);
			return;
		}

		target.setCurrentHP(target.getCurrentHP() + 2);

	}

	public void useHeroPower(Minion Target) throws NotEnoughManaException, HeroPowerAlreadyUsedException,
			NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException {

		super.useHeroPower();
		if (this.getField().size() == 7)
			throw new FullFieldException("the feild is full");

		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Prophet Velen"))
				Target.setCurrentHP(Target.getCurrentHP() + 8);
			return;
		}

		Target.setCurrentHP(this.getCurrentHP() + 2);

	}

	public Card drawCard() throws FullHandException, CloneNotSupportedException {

		return super.drawCard();
	}

}

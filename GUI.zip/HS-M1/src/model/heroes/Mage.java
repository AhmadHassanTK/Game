package model.heroes;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Collections;

import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotYourTurnException;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.minions.MinionListener;
import model.cards.spells.AOESpell;
import model.cards.spells.FieldSpell;
import model.cards.spells.Flamestrike;
import model.cards.spells.HeroTargetSpell;
import model.cards.spells.LeechingSpell;
import model.cards.spells.MinionTargetSpell;
import model.cards.spells.Polymorph;
import model.cards.spells.Pyroblast;
import model.cards.spells.Spell;

public class Mage extends Hero implements MinionListener {

	public Mage() throws IOException, CloneNotSupportedException {

		super("Jaina Proudmoore");
	}

	@Override
	public void buildDeck() throws IOException, CloneNotSupportedException {
		ArrayList<Minion> neutrals = getNeutralMinions(getAllNeutralMinions("neutral_minions.csv"), 13);
		getDeck().addAll(neutrals);

		for (int i = 0; i < 2; i++) {
			getDeck().add(new Polymorph());
			getDeck().add(new Flamestrike());
			getDeck().add(new Pyroblast());
		}
		Minion kalycgos = (new Minion("Kalycgos", 10, Rarity.LEGENDARY, 4, 12, false, false, false));
		;
		getDeck().add(kalycgos);
		Collections.shuffle(getDeck());
		for (int i = 0; i < this.getDeck().size(); i++) {
			if (this.getDeck().get(i) instanceof Minion) {
				((Minion) this.getDeck().get(i)).setListener(this);
			}
		}

	}

	public void useHeroPower(Minion target) throws NotEnoughManaException, HeroPowerAlreadyUsedException,
			NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException {

		super.useHeroPower();
		if (target.isDivine())
			target.setDivine(false);
		else
			target.setCurrentHP(target.getCurrentHP() - 1);
	}

	public void useHeroPower(Hero target) throws NotEnoughManaException, HeroPowerAlreadyUsedException,
			NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException {

		super.useHeroPower();
		super.getListener().damageOpponent(1);
		if (target.getCurrentHP() == 0)
			super.getListener().onHeroDeath();

		// target.setCurrentHP(target.getCurrentHP() - 1);
	}

	public void castSpell(LeechingSpell s, Minion m) throws NotYourTurnException, NotEnoughManaException {

		boolean flag = false;
		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Kalycgos")) {
				flag = true;
				break;
			}

		}
		if (flag) {
			Spell spell = (Spell) s;
			int temp = spell.getManaCost();
			spell.setManaCost(temp - 4);
		}
		super.castSpell(s, m);

	}

	public void castSpell(FieldSpell s) throws NotYourTurnException, NotEnoughManaException {

		boolean flag = false;
		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Kalycgos")) {
				flag = true;
				break;
			}

		}
		if (flag) {
			Spell spell = (Spell) s;
			int temp = spell.getManaCost();
			spell.setManaCost(temp - 4);
		}
		super.castSpell(s);

	}

	public void castSpell(MinionTargetSpell s, Minion m)
			throws NotYourTurnException, NotEnoughManaException, InvalidTargetException {
		boolean flag = false;
		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Kalycgos")) {
				flag = true;
				break;
			}

		}
		if (flag) {
			Spell spell = (Spell) s;
			int temp = spell.getManaCost();
			spell.setManaCost(temp - 4);
		}
		super.castSpell(s, m);
	}

	public void castSpell(AOESpell s, ArrayList<Minion> oppField) throws NotYourTurnException, NotEnoughManaException {
		boolean flag = false;
		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Kalycgos")) {
				flag = true;
				break;
			}

		}
		if (flag) {
			Spell spell = (Spell) s;
			int temp = spell.getManaCost();
			spell.setManaCost(temp - 4);
		}
		super.castSpell(s, oppField);
	}

	public void castSpell(HeroTargetSpell s, Hero h) throws NotYourTurnException, NotEnoughManaException {
		boolean flag = false;
		for (int i = 0; i < this.getField().size(); i++) {
			if (this.getField().get(i).getName().equals("Kalycgos")) {
				flag = true;
				break;
			}

		}
		if (flag) {
			Spell spell = (Spell) s;
			int temp = spell.getManaCost();
			spell.setManaCost(temp - 4);
		}
		super.castSpell(s, h);
	}

}

package model.heroes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.NotEnoughManaException;
import exceptions.NotYourTurnException;
import model.cards.Rarity;
import model.cards.minions.Minion;
import model.cards.minions.MinionListener;
import model.cards.spells.KillCommand;
import model.cards.spells.MultiShot;

public class Hunter extends Hero implements MinionListener {

	public Hunter() throws IOException, CloneNotSupportedException {
		super("Rexxar");

	}

	@Override
	public void buildDeck() throws IOException, CloneNotSupportedException {
		ArrayList<Minion> neutrals = getNeutralMinions(getAllNeutralMinions("neutral_minions.csv"), 15);
		getDeck().addAll(neutrals);

		for (int i = 0; i < 2; i++) {
			getDeck().add(new KillCommand());
			getDeck().add(new MultiShot());

		}
		Minion krush = (new Minion("King Krush", 9, Rarity.LEGENDARY, 8, 8, false, false, true));

		getDeck().add(krush);
		Collections.shuffle(getDeck());
		for (int i = 0; i < this.getDeck().size(); i++) {
			if (this.getDeck().get(i) instanceof Minion) {
				((Minion) this.getDeck().get(i)).setListener(this);
			}

		}
	}

	public void useHeroPower(Hero target) throws NotEnoughManaException, HeroPowerAlreadyUsedException,
			NotYourTurnException, FullHandException, FullFieldException, CloneNotSupportedException {
		super.useHeroPower();
		super.getListener().damageOpponent(2);
		if (target.getCurrentHP() == 0)
			super.getListener().onHeroDeath();

		// target.setCurrentHP(target.getCurrentHP() - 2);

	}

}

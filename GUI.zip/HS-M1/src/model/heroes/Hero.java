package model.heroes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import engine.ActionValidator;
import exceptions.CannotAttackException;
import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotSummonedException;
import exceptions.NotYourTurnException;
import exceptions.TauntBypassException;
import model.cards.Card;
import model.cards.Rarity;
import model.cards.minions.Icehowl;
import model.cards.minions.Minion;
import model.cards.minions.MinionListener;
import model.cards.spells.AOESpell;
import model.cards.spells.FieldSpell;
import model.cards.spells.HeroTargetSpell;
import model.cards.spells.LeechingSpell;
import model.cards.spells.MinionTargetSpell;
import model.cards.spells.Spell;

public abstract class Hero implements MinionListener {
	private String name;
	private int currentHP;
	private boolean heroPowerUsed;
	private int totalManaCrystals;
	private int currentManaCrystals;
	private ArrayList<Card> deck;
	private ArrayList<Minion> field;
	private ArrayList<Card> hand;
	@SuppressWarnings("unused")
	private int fatigueDamage;
	private HeroListener listener;
	private ActionValidator validator;

	public Hero(String name) throws IOException, CloneNotSupportedException {
		this.name = name;
		currentHP = 30;
		deck = new ArrayList<Card>();
		field = new ArrayList<Minion>();
		hand = new ArrayList<Card>();
		buildDeck();
	}

	public abstract void buildDeck() throws IOException, CloneNotSupportedException;

	public static final ArrayList<Minion> getAllNeutralMinions(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		ArrayList<Minion> minions = new ArrayList<Minion>();
		String current = br.readLine();
		while (current != null) {
			String[] line = current.split(",");
			Minion minion = null;
			String n = line[0];
			int m = Integer.parseInt(line[1]);
			Rarity r = null;
			switch ((line[2])) {
			case "b":
				r = Rarity.BASIC;
				break;
			case "c":
				r = Rarity.COMMON;
				break;
			case "r":
				r = Rarity.RARE;
				break;
			case "e":
				r = Rarity.EPIC;
				break;
			case "l":
				r = Rarity.LEGENDARY;
				break;
			}
			int a = Integer.parseInt(line[3]);
			int p = Integer.parseInt(line[4]);
			boolean t = line[5].equals("TRUE") ? true : false;
			boolean d = line[6].equals("TRUE") ? true : false;
			boolean c = line[7].equals("TRUE") ? true : false;
			if (!n.equals("Icehowl"))
				minion = new Minion(n, m, r, a, p, t, d, c);
			else
				minion = new Icehowl();
			minions.add(minion);
			current = br.readLine();
		}
		br.close();
		return minions;
	}

	public static final ArrayList<Minion> getNeutralMinions(ArrayList<Minion> minions, int count)
			throws CloneNotSupportedException {
		ArrayList<Minion> res = new ArrayList<Minion>();
		int i = 0;
		while (i < count) {

			int index = (int) (Math.random() * minions.size());
			Minion minion = minions.get(index);

			int occ = 0;
			for (int j = 0; j < res.size(); j++) {
				if (res.get(j).getName().equals(minion.getName()))
					occ++;
			}
			if (occ == 0) {
				res.add(minion);
				i++;
			} else if (occ == 1 && minion.getRarity() != Rarity.LEGENDARY) {
				Minion u = minion.clone();
				res.add(u);
				i++;
			}
		}
		return res;
	}

	public int getCurrentHP() {
		return currentHP;
	}

	public void setCurrentHP(int hp) {
		this.currentHP = hp;
		if (this.currentHP > 30)
			this.currentHP = 30;
		else if (this.currentHP <= 0) {
			this.currentHP = 0;

		}
		if (this.currentHP == 0)
			listener.onHeroDeath();
	}

	public int getTotalManaCrystals() {
		return totalManaCrystals;
	}

	public void setTotalManaCrystals(int totalManaCrystals) {
		this.totalManaCrystals = totalManaCrystals;
		if (this.totalManaCrystals > 10)
			this.totalManaCrystals = 10;
	}

	public int getCurrentManaCrystals() {
		return currentManaCrystals;
	}

	public void setCurrentManaCrystals(int currentManaCrystals) {
		this.currentManaCrystals = currentManaCrystals;
		if (this.currentManaCrystals > 10)
			this.currentManaCrystals = 10;
	}

	public ArrayList<Minion> getField() {
		return field;
	}

	public ArrayList<Card> getHand() {
		return hand;
	}

	public boolean isHeroPowerUsed() {
		return heroPowerUsed;
	}

	public ArrayList<Card> getDeck() {

		return deck;
	}

	public void setHeroPowerUsed(boolean powerUsed) {
		this.heroPowerUsed = powerUsed;
	}

	public String getName() {
		return name;
	}

	public HeroListener getListener() {
		return listener;
	}

	public void setListener(HeroListener listener) {
		this.listener = listener;
	}

	public void setValidator(ActionValidator validator) {

		this.validator = validator;
	}

	public void useHeroPower() throws NotEnoughManaException, HeroPowerAlreadyUsedException, NotYourTurnException,
			FullHandException, FullFieldException, CloneNotSupportedException {
		validator.validateTurn(this);
		validator.validateUsingHeroPower(this);

		if (this.hand.size() == 10)
			throw new FullHandException(null);
		this.currentManaCrystals = this.currentManaCrystals - 2;
		this.setHeroPowerUsed(true);
	}

	public void playMinion(Minion m) throws NotYourTurnException, NotEnoughManaException, FullFieldException {
		validator.validateManaCost(m);
		validator.validateTurn(this);
		validator.validatePlayingMinion(m);

		int l = this.hand.size();
		for (int i = 0; i < l; i++) {
			if (this.hand.get(i).equals(m)) {
				this.field.add(m);
				this.hand.remove(i);
			}
		}
		this.currentManaCrystals = this.currentManaCrystals - m.getManaCost();

	}

	public void attackWithMinion(Minion attacker, Minion target) throws CannotAttackException, NotYourTurnException,
			TauntBypassException, InvalidTargetException, NotSummonedException {
		validator.validateTurn(this);
		validator.validateAttack(attacker, target);
		attacker.attack(target);

	}

	public void attackWithMinion(Minion attacker, Hero target) throws CannotAttackException, NotYourTurnException,
			TauntBypassException, NotSummonedException, InvalidTargetException {
		validator.validateTurn(this);
		validator.validateAttack(attacker, target);
		attacker.attack(target);
	}

	public void castSpell(FieldSpell s) throws NotYourTurnException, NotEnoughManaException {
		validator.validateTurn(this);

		validator.validateManaCost((Card) s);
		Card f = (Card) s;

		s.performAction(this.field);
		this.currentManaCrystals = this.currentManaCrystals - f.getManaCost();
		this.hand.remove(s);

	}

	public void castSpell(AOESpell s, ArrayList<Minion> oppField) throws NotYourTurnException, NotEnoughManaException {
		validator.validateTurn(this);

		validator.validateManaCost((Card) s);
		Card f = (Card) s;

		this.currentManaCrystals = this.currentManaCrystals - f.getManaCost();
		this.hand.remove(s);

		s.performAction(oppField, this.getField());

		for (int k = 0; k < oppField.size(); k++) {
			if (oppField.get(k).getCurrentHP() == 0) {
				onMinionDeath(oppField.get(k));
				k--;
			}

		}
		for (int k = 0; k < this.field.size(); k++) {
			if (this.getField().get(k).getCurrentHP() == 0) {
				onMinionDeath(this.field.get(k));
				k--;
			}
		}

	}

	public void castSpell(MinionTargetSpell s, Minion m)
			throws NotYourTurnException, NotEnoughManaException, InvalidTargetException {

		validator.validateTurn(this);

		validator.validateManaCost((Card) s);
		Card f = (Card) s;

		if (m.isDivine()) {
			m.setDivine(false);

			this.hand.remove(s);
			if (m.getCurrentHP() == 0)
				onMinionDeath(m);
			for (int k = 0; k < this.field.size(); k++) {
				if (this.getField().get(k).getCurrentHP() == 0)
					onMinionDeath(this.field.get(k));
				this.field.get(k).setListener(this);
				k--;
			}
			return;
		}
		s.performAction(m);
		this.hand.remove(s);
		this.currentManaCrystals = this.currentManaCrystals - f.getManaCost();
	}

	public void castSpell(HeroTargetSpell s, Hero h) throws NotYourTurnException, NotEnoughManaException {
		validator.validateTurn(this);

		validator.validateManaCost((Card) s);
		Card f = (Card) s;
		s.performAction(h);
		this.hand.remove(s);
		this.currentManaCrystals = this.currentManaCrystals - f.getManaCost();

	}

	public void castSpell(LeechingSpell s, Minion m) throws NotYourTurnException, NotEnoughManaException {
		validator.validateTurn(this);

		validator.validateManaCost((Card) s);
		Card f = (Card) s;
		int temp = s.performAction(m);
		int j = this.getCurrentHP();
		this.setCurrentHP(j + temp);
		this.hand.remove(s);
		this.currentManaCrystals = this.currentManaCrystals - f.getManaCost();
		if (m.getCurrentHP() == 0) {
			onMinionDeath(m);
			m.setListener(this);

		}

	}

	public void endTurn() throws FullHandException, CloneNotSupportedException {
		listener.endTurn();

	}

	public Card drawCard() throws FullHandException, CloneNotSupportedException {
		if (this.equals(null))
			throw new NullPointerException();
		if (this.hand.size() == 10 && this.getDeck().size() > 0) {
			throw new FullHandException(this.getDeck().remove(0));
		}

		if (this.getDeck().size() == 0) {

			this.currentHP = this.currentHP - this.fatigueDamage;
			this.fatigueDamage = this.fatigueDamage + 1;
			return (null);
		}

		else {
			this.hand.add(this.deck.get(0));
		}

		boolean chromaggusFound = false;

		for (int i = 0; i < this.field.size(); i++) {
			if (this.getField().get(i).getName().equals("Chromaggus")) {
				chromaggusFound = true;
				break;
			}

		}
		if (chromaggusFound) {
			if (this.hand.size() < 10) {
				if (!(this.deck.get(0) instanceof Spell))
					this.deck.get(0).setManaCost(0);
				this.hand.add(this.deck.get(0).clone());
			}
		}

		Card temp = this.deck.remove(0);

		if (this.deck.size() == 0)
			this.fatigueDamage = 1;
		return (temp);
	}

	public void onMinionDeath(Minion m) {
		this.getField().remove(m);
		m.setListener(this);

	}

}

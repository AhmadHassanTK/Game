package model.cards.spells;

import java.util.ArrayList;
import model.cards.Rarity;
import model.cards.minions.Minion;

public class Flamestrike extends Spell implements AOESpell {

	public Flamestrike() {
		super("Flamestrike", 7, Rarity.BASIC);
	}

	@Override
	public void performAction(ArrayList<Minion> oppField, ArrayList<Minion> curField) {

		for (int k = 0; k < oppField.size(); k++) {
			int minionHP = oppField.get(k).getCurrentHP();

			if (oppField.get(k).isDivine())
				oppField.get(k).setDivine(false);
			else {

				minionHP -= 4;
				oppField.get(k).setCurrentHP(minionHP);
			}

			if (minionHP == 0) {
				k--;
			}

		}
	}
}

package model.cards.spells;

import java.util.ArrayList;

import model.cards.Rarity;
import model.cards.minions.Minion;

public class MultiShot extends Spell implements AOESpell {

	public MultiShot() {
		super("Multi-Shot", 4, Rarity.BASIC);

	}

	@Override
	public void performAction(ArrayList<Minion> oppField, ArrayList<Minion> curField) {

		int z = (int) Math.random() * oppField.size();

		int x = (int) Math.random() * oppField.size();

		x = 0;

		z = 1;

		if (oppField.size() > 2) {

			int y = oppField.get(x).getCurrentHP();
			if (oppField.get(x).isDivine())
				oppField.get(x).setDivine(false);
			else {
				oppField.get(x).setCurrentHP(y - 3);
			}

			int j = oppField.get(z).getCurrentHP();
			if (oppField.get(z).isDivine())
				oppField.get(z).setDivine(false);
			else {
				oppField.get(z).setCurrentHP(j - 3);
			}

		}
		if (oppField.size() == 2) {
			int y1 = oppField.get(0).getCurrentHP();
			if (oppField.get(0).isDivine())
				oppField.get(0).setDivine(false);
			else {
				oppField.get(0).setCurrentHP(y1 - 3);
			}
			int y2 = oppField.get(1).getCurrentHP();
			if (oppField.get(1).isDivine())
				oppField.get(1).setDivine(false);
			else {
				oppField.get(1).setCurrentHP(y2 - 3);
			}
		}
		if (oppField.size() == 1) {
			int y3 = oppField.get(0).getCurrentHP();
			if (oppField.get(0).isDivine())
				oppField.get(0).setDivine(false);
			else {
				oppField.get(0).setCurrentHP(y3 - 3);
			}
		}

	}

}

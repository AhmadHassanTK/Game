package model.cards.spells;

import java.util.ArrayList;

import model.cards.Rarity;
import model.cards.minions.Minion;

public class LevelUp extends Spell implements FieldSpell {

	public LevelUp() {
		super("Level Up!", 6, Rarity.EPIC);

	}

	@Override
	public void performAction(ArrayList<Minion> field) {
		for (int i = 0; i < field.size(); i++) {
			if (field.get(i).getName().equals("Silver Hand Recruit")) {
				int u = field.get(i).getAttack();
				int x = field.get(i).getCurrentHP();
				int y = field.get(i).getMaxHP();
				field.get(i).setAttack(u + 1);
				field.get(i).setMaxHP(y + 1);
				field.get(i).setCurrentHP(x + 1);

			}
		}

	}

}

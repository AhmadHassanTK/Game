package model.cards.spells;

import exceptions.InvalidTargetException;
import model.cards.Rarity;
import model.cards.minions.Minion;

public class DivineSpirit extends Spell implements MinionTargetSpell {

	public DivineSpirit() {
		super("Divine Spirit", 3, Rarity.BASIC);

	}

	@Override
	public void performAction(Minion m) throws InvalidTargetException {
		int x = m.getCurrentHP();
		int y = m.getMaxHP();
		m.setMaxHP(2 * y);
		m.setCurrentHP(2 * x);

	}

}

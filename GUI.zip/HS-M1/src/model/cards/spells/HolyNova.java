package model.cards.spells;

import java.util.ArrayList;

import model.cards.Rarity;
import model.cards.minions.Minion;

public class HolyNova extends Spell implements AOESpell {

	public HolyNova() {
		super("Holy Nova", 5, Rarity.BASIC);

	}

	@Override
	public void performAction(ArrayList<Minion> oppField, ArrayList<Minion> curField) {

		for (int k = 0; k < oppField.size(); k++) {

			int y = oppField.get(k).getCurrentHP();

			if (oppField.get(k).isDivine())
				oppField.get(k).setDivine(false);
			else {

				y -= 2;
				oppField.get(k).setCurrentHP(y);
				if (y == 0)
					k--;

			}
		}

		for (int i = 0; i < curField.size(); i++) {
			int y = curField.get(i).getCurrentHP();
			curField.get(i).setCurrentHP(y + 2);

		}
	}

}
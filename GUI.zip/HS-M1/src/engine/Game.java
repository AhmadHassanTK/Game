package engine;

import exceptions.CannotAttackException;
import exceptions.FullFieldException;
import exceptions.FullHandException;
import exceptions.HeroPowerAlreadyUsedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughManaException;
import exceptions.NotSummonedException;
import exceptions.NotYourTurnException;
import exceptions.TauntBypassException;
import model.cards.Card;
import model.cards.minions.Minion;
import model.heroes.Hero;
import model.heroes.HeroListener;

public class Game  implements HeroListener,ActionValidator{
	private Hero firstHero;
	private Hero secondHero;
	private Hero currentHero;
	private Hero opponent;
 private GameListener listener;
	
	
	public Game(Hero p1, Hero p2) throws CloneNotSupportedException, FullHandException
	{
		firstHero=p1;
		secondHero=p2;
		
		int coin = (int) (Math.random()*2);
		currentHero= coin==0?firstHero:secondHero;
		opponent= currentHero==firstHero?secondHero:firstHero;
		currentHero.setCurrentManaCrystals(1);
		currentHero.setTotalManaCrystals(1);
		currentHero.setListener(this);
		opponent.setListener(this);
		
		
		currentHero.drawCard();
		currentHero.drawCard();
		currentHero.drawCard();
		opponent.drawCard();
		opponent.drawCard();
		opponent.drawCard();
		opponent.drawCard();
		
			currentHero.setValidator(this);
			opponent.setValidator(this);}
		
		
	

	public Hero getCurrentHero() {
		return currentHero;
	}

	public Hero getOpponent() {
		return opponent;
	}

	@Override
	public void onHeroDeath() {
		listener.onGameOver();
		
	}

	@Override
	public void damageOpponent(int amount) {
		this.opponent.setCurrentHP(this.opponent.getCurrentHP()-amount);
		
	}

	@Override
	public void endTurn() throws FullHandException, CloneNotSupportedException {
	
	Hero temp=currentHero;
	currentHero=opponent;
	opponent=temp;
	int u =currentHero.getTotalManaCrystals();
	int r =u+1;
	currentHero.setTotalManaCrystals(r);
	currentHero.setCurrentManaCrystals(r);
	currentHero.setHeroPowerUsed(false);
	opponent.setHeroPowerUsed(false);
	for(int i=0;i<currentHero.getField().size();i++){
		currentHero.getField().get(i).setSleeping(false);
		currentHero.getField().get(i).setAttacked(false);
		
	}
	currentHero.drawCard();
	
	}
	public void validateTurn(Hero user) throws NotYourTurnException{
		if(!(user.equals(currentHero))){
			throw new NotYourTurnException(" not your turn");
		}
		this.currentHero.equals(user);
			
	}

	@Override
	public void validateAttack(Minion attacker, Minion target)
			throws CannotAttackException, NotSummonedException,
			TauntBypassException, InvalidTargetException {
		if(attacker.isSleeping()||attacker.isAttacked()||attacker.getAttack()==0){
			throw new CannotAttackException(" not available ");
		}
		if ((currentHero.getField().contains(target) && currentHero.getField().contains(attacker)))
			throw new InvalidTargetException("Friendly Minions");

		if(currentHero.getHand().contains(attacker)&&!(opponent.getField().contains(target))){
			throw new NotSummonedException("can't play this minion"); 
		}
		if (!(currentHero.getField().contains(attacker)) || !opponent.getField().contains(target))
			throw new NotSummonedException("can't play this minion");


		boolean flag=false;
				Minion y=null;
				for(int k=0;k<getOpponent().getField().size();k++){
					if(getOpponent().getField().get(k).isTaunt()){
						flag=true;
					y=getOpponent().getField().get(k);
					break;}}
				
				if(flag==true && !(target.equals(y)) ){
					throw new TauntBypassException("there is a taunt  ");
				}
				
//				if((currentHero.getField().contains(target))){
//					throw new InvalidTargetException("invalid");
//				}
		
	}

	@Override
	public void validateAttack(Minion attacker, Hero target)
			throws CannotAttackException, NotSummonedException,
			TauntBypassException, InvalidTargetException {
		if(attacker.isSleeping()||attacker.isAttacked()){
			throw new CannotAttackException(" not available ");
		}
		if(this.currentHero.equals(target))
			throw new CannotAttackException("this is a friendly hero");
		if(currentHero.getHand().contains(attacker)||!(currentHero.getField().contains(attacker))){
			throw new NotSummonedException("can't play this minion"); 
		}
		if(attacker.getAttack()==0)
			throw new CannotAttackException("no attack points");
		boolean flag=false;
				Minion y=null;
				for(int k=0;k<getOpponent().getField().size();k++){
					if(getOpponent().getField().get(k).isTaunt())
						flag=true;
					y=getOpponent().getField().get(k);
					break;
				}if(flag==true  ){
					throw new TauntBypassException("there is a taunt  ");
				}
				if(attacker.getName().equals("Icehowl")&&!(attacker.getName().equalsIgnoreCase("Sheep"))){
					throw new InvalidTargetException("invalid");
				}
		
		
		
	}

	@Override
	public void validateManaCost(Card card) throws NotEnoughManaException {
		if(currentHero.getCurrentManaCrystals()<card.getManaCost()){
	    	throw new NotEnoughManaException("not enough");
	    	
	    }
	    
		
	}

	@Override
	public void validatePlayingMinion(Minion minion) throws FullFieldException {
		if (currentHero.getField().size()==7){
	    	throw new FullFieldException("the feild is full");
	     }
		
	}

	@Override
	public void validateUsingHeroPower(Hero hero)
			throws NotEnoughManaException, HeroPowerAlreadyUsedException {
		if(currentHero.getCurrentManaCrystals()<2){
	    	throw new NotEnoughManaException("not enough");}
	    	if(hero.isHeroPowerUsed()){
	    		throw new HeroPowerAlreadyUsedException("power is already used ");
	    	}
		
	}

	
	public void setListener(GameListener listener) {
		this.listener = listener;
	}

	
	
	}


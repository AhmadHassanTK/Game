package engine;

public interface GameListener {
	public void onGameOver();
}

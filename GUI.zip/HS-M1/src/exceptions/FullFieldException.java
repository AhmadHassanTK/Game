package exceptions;

@SuppressWarnings("serial")
public class FullFieldException extends HearthstoneException {

	public FullFieldException() {
		super();
	}

	public FullFieldException(String message) {
		super(message);

	}

}
